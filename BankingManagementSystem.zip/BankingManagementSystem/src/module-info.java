/**
 * 
 */
/**
 * @author AKFALI
 *
 */
module BankingManagementSystem {
	requires java.desktop;
}