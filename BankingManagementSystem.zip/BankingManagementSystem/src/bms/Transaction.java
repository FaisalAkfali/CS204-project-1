package bms;

class Transaction {
    private String type; 
    private double amount;
    private String fromAccountId;
    private String toAccountId;

    public Transaction(String type, double amount, String fromAccountId, String toAccountId) {
        this.type = type;
        this.amount = amount;
        this.fromAccountId = fromAccountId;
        this.toAccountId = toAccountId;
    }

    @Override
    public String toString() {
        return String.format("Transaction Type: %s\nAmount: $%.2f\nFrom: %s\nTo: %s", type, amount, fromAccountId, toAccountId);
    }
}