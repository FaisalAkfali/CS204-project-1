package bms;

class Account {
    private String accountId;
    private String username; 
    private String password;
    private double balance;

    public Account(String accountId, String username, String password) {
        this.accountId = accountId;
        this.username = username; 
        this.password = password; 
        this.balance = 0.0;
    }

    public String getAccountId() {
        return accountId;
    }

    public String getUsername() {
        return username; 
    }

    public double getBalance() {
        return balance;
    }

    public String getPassword() {
        return password; 
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Successfully deposited: $" + amount + " to account: " + accountId);
        } else {
            throw new IllegalArgumentException("Deposit amount must be positive.");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Successfully withdrew: $" + amount + " from account: " + accountId);
        } else {
            throw new IllegalArgumentException("Invalid withdrawal amount.");
        }
    }

    public void updateUsername(String newUsername) {
        this.username = newUsername;
        System.out.println("Username updated to: " + newUsername);
    }

    public void updatePassword(String newPassword) {
        this.password = newPassword;
        System.out.println("Password updated successfully.");
    }
    public void updateAccountId(String newAccountId) {
        this.accountId = newAccountId;
        System.out.println("Account ID updated to: " + newAccountId);
    }

    @Override
    public String toString() {
        return String.format("Account ID: %s\nUsername: %s\nBalance: $%.2f", accountId, username, balance);
    }
}