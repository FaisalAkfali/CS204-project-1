package bms;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		BankingManagementSystem bms = new BankingManagementSystem();
        Scanner scanner = new Scanner(System.in);
        String choice;

        do {
        	System.out.println("==============================");
            System.out.println("Banking Management System");
            System.out.println("==============================");
            System.out.println("1. Login");
            System.out.println("2. Create Account");
            System.out.println("3. Deposit");
            System.out.println("4. Withdraw");
            System.out.println("5. Transfer");
            System.out.println("6. Balance Inquiry");
            System.out.println("7. Delete Account");
            System.out.println("8. Update Username");
            System.out.println("9. Update Password");
            System.out.println("10. Update Account ID");
            System.out.println("11. Display All Accounts");
            System.out.println("12. Display Transaction History");
            System.out.println("13. Logout");
            System.out.println("14. Exit");
            System.out.println("==============================");
            System.out.print("Choose an option: ");
            choice = scanner.nextLine();
            
            if (choice.isEmpty()) {
                System.out.println("Operation cancelled. Returning to menu...");
                continue;
            }
            switch (choice) {
            case "1":
                System.out.print("Enter Account ID to Login: ");
                String accountId = scanner.nextLine();
                if (accountId.isEmpty()) 
                	break;
                System.out.print("Enter Password: ");
                String password = scanner.nextLine();
                if(password.isEmpty())
                	break;
                bms.login(accountId, password);
                break;
            case "2":
                System.out.print("Enter Account ID: ");
                accountId = scanner.nextLine();
                if(accountId.isEmpty()) 
                	break;
                System.out.print("Enter Username: ");
                String username = scanner.nextLine();
                if(username.isEmpty())
                	break;
                System.out.print("Enter Password: ");
                String newPassword = scanner.nextLine();
                bms.createAccount(accountId, username, newPassword);
                break;
            case "3": 
                System.out.print("Enter Amount to Deposit: ");
                double depositAmount = Double.parseDouble(scanner.nextLine());
                bms.deposit(depositAmount);
                break;
            case "4": 
                System.out.print("Enter Amount to Withdraw: ");
                double withdrawAmount = Double.parseDouble(scanner.nextLine());
                bms.withdraw(withdrawAmount);
                break;
            case "5": 
                System.out.print("Enter To Account ID: ");
                String toAccountId = scanner.nextLine();
                System.out.print("Enter Amount to Transfer: ");
                double transferAmount = Double.parseDouble(scanner.nextLine());
                bms.transfer(toAccountId, transferAmount);
                break;
            case "6": 
                bms.balanceInquiry();
                break;
            case "7": 
                bms.deleteAccount();
                break;
            case "8": 
                System.out.print("Enter New Username: ");
                String newUsername = scanner.nextLine();
                bms.updateUsername(newUsername);
                break;
            case "9": 
                System.out.print("Enter New Password: ");
                String updatedPassword = scanner.nextLine();
                bms.updatePassword(updatedPassword);
                break;
            case "10": 
                System.out.print("Enter New Account ID: ");
                String newAccountId = scanner.nextLine();
                bms.updateAccountId(newAccountId);
                break;
            case "11": 
                bms.displayAllAccounts();
                break;
            case "12": 
                bms.displayTransactionHistory();
                break;
            case "13": 
                bms.logout();
                break;
            case "14": 
                System.out.println("Exiting the Banking Management System. Thank you!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    } while (!choice.equals("14"));
        }
	}
