package bms;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

class AccountManager { 
    private Map<String, Account> accounts;
    private Queue<Transaction> transactionHistory;

    public AccountManager() {
        accounts = new HashMap<>();
        transactionHistory = new LinkedList<>();
    }

    public void createAccount(String accountId, String username, String password) {
        if (!accounts.containsKey(accountId)) {
            accounts.put(accountId, new Account(accountId, username, password));
            System.out.println("Account created for: " + username);
        } else {
            System.out.println("Account with ID " + accountId + " already exists.");
        }
    }

    public Account getAccount(String accountId) {
        return accounts.get(accountId);
    }

    public void deleteAccount(String accountId) {
        if (accounts.remove(accountId) != null) {
            System.out.println("Account " + accountId + " deleted successfully.");
        } else {
            System.out.println("Account not found.");
        }
    }

    public void updateUsername(String accountId, String newUsername) {
        Account account = getAccount(accountId);
        if (account != null) {
            account.updateUsername(newUsername);
        } else {
            System.out.println("Account not found.");
        }
    }

    public void updatePassword(String accountId, String newPassword) {
        Account account = getAccount(accountId);
        if (account != null) {
            account.updatePassword(newPassword);
        } else {
            System.out.println("Account not found.");
        }
    }
    public void updateAccountId(String oldAccountId, String newAccountId) {
        Account account = getAccount(oldAccountId);
        if (account != null) {
            if (!accounts.containsKey(newAccountId)) {
                accounts.remove(oldAccountId);
                account.updateAccountId(newAccountId);
                accounts.put(newAccountId, account);
                System.out.println("Account ID updated successfully.");
            } else {
                System.out.println("Account ID " + newAccountId + " already exists .");
            }
        } else {
            System.out.println("Account not found.");
        }
    }

    public void recordTransaction(Transaction transaction) {
        transactionHistory.add(transaction);
    }

    public void displayTransactionHistory() {
        if (transactionHistory.isEmpty()) {
            System.out.println("No transaction history available.");
            return;
        }
        System.out.println("Transaction History:");
        while (!transactionHistory.isEmpty()) {
            Transaction transaction = transactionHistory.poll();
            System.out.println(transaction);
        }
    }

    public void displayAllAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts available.");
            return;
        }
        System.out.println("All Accounts:");
        for (Account account : accounts.values()) {
            System.out.println(account);
        }
    }
}