package bms;

class BankingManagementSystem {
    private AccountManager accountManager;
    private String loggedInAccountId;

    public BankingManagementSystem() {
        accountManager = new AccountManager();
        loggedInAccountId = null;
    }

    public void createAccount(String accountId, String username, String password) {
        accountManager.createAccount(accountId, username, password);
    }

    public void login(String accountId, String password) {
        Account account = accountManager.getAccount(accountId);
        if (account != null && account.getPassword().equals(password)) {
            loggedInAccountId = accountId;
            System.out.println("Login successful for account: " + accountId);
        } else {
            System.out.println("Invalid account ID or password.");
        }
    }

    public void logout() {
        if (loggedInAccountId != null) {
            loggedInAccountId = null;
            System.out.println("Logged out successfully.");
        } else {
            System.out.println("No user is currently logged in.");
        }
    }

    public void deposit(double amount) {
        if (loggedInAccountId != null) {
            Account account = accountManager.getAccount(loggedInAccountId);
            try {
                account.deposit(amount);
                accountManager.recordTransaction(new Transaction("DEPOSIT", amount, loggedInAccountId, null));
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void withdraw(double amount) {
        if (loggedInAccountId != null) {
            Account account = accountManager.getAccount(loggedInAccountId);
            try {
                account.withdraw(amount);
                accountManager.recordTransaction(new Transaction("WITHDRAW", amount, loggedInAccountId, null));
            } catch (IllegalArgumentException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void transfer(String toAccountId, double amount) {
        if (loggedInAccountId != null) {
            Account fromAccount = accountManager.getAccount(loggedInAccountId);
            Account toAccount = accountManager.getAccount(toAccountId);
            if (toAccount != null) {
                try {
                    fromAccount.withdraw(amount);
                    toAccount.deposit(amount);
                    accountManager.recordTransaction(new Transaction("TRANSFER", amount, loggedInAccountId, toAccountId));
                    System.out.println("Successfully transferred: $" + amount + " from " + loggedInAccountId + " to " + toAccountId);
                } catch (IllegalArgumentException e) {
                    System.out.println(e.getMessage());
                }
            } else {
                System.out.println("Recipient account not found.");
            }
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void balanceInquiry() {
        if (loggedInAccountId != null) {
            Account account = accountManager.getAccount(loggedInAccountId);
            System.out.println("Balance for account " + loggedInAccountId + ": $" + account.getBalance());
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void deleteAccount() {
        if (loggedInAccountId != null) {
            accountManager.deleteAccount(loggedInAccountId);
            loggedInAccountId = null;
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void updateUsername(String newUsername) {
        if (loggedInAccountId != null) {
            accountManager.updateUsername(loggedInAccountId, newUsername);
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void updatePassword(String newPassword) {
        if (loggedInAccountId != null) {
            accountManager.updatePassword(loggedInAccountId, newPassword);
        } else {
            System.out.println("Please log in first.");
        }
    }
    
    public void updateAccountId(String newAccountId) {
        if (loggedInAccountId != null) {
            accountManager.updateAccountId(loggedInAccountId, newAccountId);
            loggedInAccountId = newAccountId;
        } else {
            System.out.println("Please log in first.");
        }
    }

    public void displayAllAccounts() {
        accountManager.displayAllAccounts();
    }

    public void displayTransactionHistory() {
        accountManager.displayTransactionHistory();
    }
}
