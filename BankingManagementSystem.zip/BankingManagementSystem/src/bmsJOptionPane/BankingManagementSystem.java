package bmsJOptionPane;

import javax.swing.JOptionPane;


class BankingManagementSystem {
    private AccountManager accountManager;
    private String loggedInAccountId;

    public BankingManagementSystem() {
        accountManager = new AccountManager();
        loggedInAccountId = null;
    }

    public void createAccount(String accountId, String username, String password) {
        accountManager.createAccount(accountId, username, password);
    }

    public void login(String accountId, String password) {
        Account account = accountManager.getAccount(accountId);
        if (account != null && account.getPassword().equals(password)) {
            loggedInAccountId = accountId;
            JOptionPane.showMessageDialog(null, "Login successful for account: " + accountId);
        } else {
            JOptionPane.showMessageDialog(null, "Invalid account ID or password.");
        }
    }

    public void logout() {
        if (loggedInAccountId != null) {
            loggedInAccountId = null;
            JOptionPane.showMessageDialog(null, "Logged out successfully.");
        } else {
            JOptionPane.showMessageDialog(null, "No user is currently logged in.");
        }
    }

    public void deposit(double amount) {
        if (loggedInAccountId != null) {
            Account account = accountManager.getAccount(loggedInAccountId);
            try {
                account.deposit(amount);
                accountManager.recordTransaction(new Transaction("DEPOSIT", amount, loggedInAccountId, null));
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }

    public void withdraw(double amount) {
        if (loggedInAccountId != null) {
            Account account = accountManager.getAccount(loggedInAccountId);
            try {
                account.withdraw(amount);
                accountManager.recordTransaction(new Transaction("WITHDRAW", amount, loggedInAccountId, null));
            } catch (IllegalArgumentException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }

    public void transfer(String toAccountId, double amount) {
        if (loggedInAccountId != null) {
            Account fromAccount = accountManager.getAccount(loggedInAccountId);
            Account toAccount = accountManager.getAccount(toAccountId);
            if (toAccount != null) {
                try {
                    fromAccount.withdraw(amount);
                    toAccount.deposit(amount);
                    accountManager.recordTransaction(new Transaction("TRANSFER", amount, loggedInAccountId, toAccountId));
                    JOptionPane.showMessageDialog(null, "Successfully transferred: $" + amount + " from " + loggedInAccountId + " to " 
                    + toAccountId);
                } catch (IllegalArgumentException e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            } else {
                JOptionPane.showMessageDialog(null, "Recipient account not found.");
            }
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }

    public void balanceInquiry() {
        if (loggedInAccountId != null) {
            Account account = accountManager.getAccount(loggedInAccountId);
            JOptionPane.showMessageDialog(null, "Balance for account " + loggedInAccountId + ": $" 
            + account.getBalance());
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }
    		
    public void deleteAccount() {					
        if (loggedInAccountId != null) {			 
            accountManager.deleteAccount(loggedInAccountId);
            loggedInAccountId = null;
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }

    public void updateUsername(String newUsername) { 
        if (loggedInAccountId != null) {
            accountManager.updateUsername(loggedInAccountId, newUsername);
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }

    public void updatePassword(String newPassword) {
        if (loggedInAccountId != null) {
            accountManager.updatePassword(loggedInAccountId, newPassword);
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");
        }
    }

    public void updateAccountId(String newAccountId) {
        if (loggedInAccountId != null) {
            accountManager.updateAccountId(loggedInAccountId, newAccountId);
            loggedInAccountId = newAccountId; 
        } else {
            JOptionPane.showMessageDialog(null, "Please login first.");										
        }
    }

    public void displayAllAccounts() {
        accountManager.displayAllAccounts();
    }

    public void displayTransactionHistory() {
        accountManager.displayTransactionHistory();
    }
}
