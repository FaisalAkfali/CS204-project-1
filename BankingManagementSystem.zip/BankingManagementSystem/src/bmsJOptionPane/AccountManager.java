package bmsJOptionPane;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import javax.swing.JOptionPane;

class AccountManager {
    private Map<String, Account> accounts;
    private Queue<Transaction> transactionHistory;

    public AccountManager() {
        accounts = new HashMap<>();
        transactionHistory = new LinkedList<>();
    }

    public void createAccount(String accountId, String username, String password) {
        if (!accounts.containsKey(accountId)) {
            accounts.put(accountId, new Account(accountId, username, password));
            JOptionPane.showMessageDialog(null, "Account created for: " + username);
        } else {
            JOptionPane.showMessageDialog(null,"Account with ID " + accountId + " already exists.");
        }
    }

    public Account getAccount(String accountId) {
        return accounts.get(accountId);
    }
    	
    public void deleteAccount(String accountId) {	
        if (accounts.remove(accountId) != null) {
            JOptionPane.showMessageDialog(null,"Account " + accountId + " deleted successfully.");
        } else {
            JOptionPane.showMessageDialog(null,"Account not found.");
        }
    }

    public void updateUsername(String accountId, String newUsername) {	
        Account account = getAccount(accountId);
        if (account != null) {
            account.updateUsername(newUsername);
        } else {
            JOptionPane.showMessageDialog(null, "Account not found.");
        }
    }

    public void updatePassword(String accountId, String newPassword) {
        Account account = getAccount(accountId);
        if (account != null) {
            account.updatePassword(newPassword);
        } else {
            JOptionPane.showMessageDialog(null,"Account not found.");
        }
    }

    public void updateAccountId(String oldAccountId, String newAccountId) {
        Account account = getAccount(oldAccountId);
        if (account != null) {
            if (!accounts.containsKey(newAccountId)) {
                accounts.remove(oldAccountId);
                account.updateAccountId(newAccountId);
                accounts.put(newAccountId, account);
                JOptionPane.showMessageDialog(null,"Account ID updated successfully.");
            } else {
                JOptionPane.showMessageDialog(null, "Account ID " + newAccountId + " already exists.");
            }
        } else {
            JOptionPane.showMessageDialog(null,"Account not found.");
        }
    }

    public void recordTransaction(Transaction transaction) {
        transactionHistory.add(transaction);
    }

    public void displayTransactionHistory() {
        if (transactionHistory.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No transaction history available.");
            return;
        }
        StringBuilder history = new StringBuilder("Transaction History:\n");
        while (!transactionHistory.isEmpty()) {
            Transaction transaction = transactionHistory.poll();
            history.append(transaction).append("\n");
        }
        JOptionPane.showMessageDialog(null, history.toString());
    }

    public void displayAllAccounts() {
        if (accounts.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No accounts available.");
            return;
        }
        StringBuilder allAccounts = new StringBuilder("All Accounts:\n");
        for (Account account : accounts.values()) {
            allAccounts.append(account).append("\n");
        }
        JOptionPane.showMessageDialog(null, allAccounts.toString());
    }
}