package bmsJOptionPane;

import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		
		BankingManagementSystem bms = new BankingManagementSystem();
		String choice;
    do {
        String menu = "Banking Management System\n" +
                      "1. Login\n" +
                      "2. Create Account\n" +
                      "3. Deposit\n" +
                      "4. Withdraw\n" +
                      "5. Transfer\n" +
                      "6. Balance Inquiry\n" +
                      "7. Delete Account\n" +
                      "8. Update Username\n" +
                      "9. Update Password\n" +
                      "10. Update Account ID\n" +
                      "11. Display All Accounts\n" +
                      "12. Display Transaction History\n" +
                      "13. Logout\n" +
                      "14. Exit";
        choice = JOptionPane.showInputDialog(menu);
        
        if(choice == null) {
        	JOptionPane.showMessageDialog(null, "Operation cancelled. Returning to menu...");
        }
        switch (choice) {
            case "1": 
                String accountId = JOptionPane.showInputDialog("Enter Account ID to Login:");
                if(accountId == null) 
                	break;
                String password = JOptionPane.showInputDialog("Enter Password:");
                if(password == null) break;
                bms.login(accountId, password);
                break;
            case "2": 
                accountId = JOptionPane.showInputDialog("Enter Account ID:");
                if(accountId == null)
                	break;
                String username = JOptionPane.showInputDialog("Enter Username:");
                if(username == null)
                	break;
                String newPassword = JOptionPane.showInputDialog("Enter Password:");
                if(newPassword == null)
                	break;
                bms.createAccount(accountId, username, newPassword);
                break;
            case "3":
                double depositAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter Amount to Deposit:"));
                bms.deposit(depositAmount);
                break;
            case "4": 
                double withdrawAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter Amount to Withdraw:"));
                bms.withdraw(withdrawAmount);
                break;
            case "5": 
                String toAccountId = JOptionPane.showInputDialog("Enter Account ID to transfer:");
                if(toAccountId == null)
                	break;
                double transferAmount = Double.parseDouble(JOptionPane.showInputDialog("Enter Amount to Transfer:"));
                bms.transfer(toAccountId, transferAmount);
                break;
            case "6": 
                bms.balanceInquiry();
                break;
            case "7": 
                bms.deleteAccount();
                break;
            case "8": 
                String newUsername = JOptionPane.showInputDialog("Enter New Username:");
                if(newUsername == null)
                	break;
                bms.updateUsername(newUsername);
                break;
            case "9": 
                String updatedPassword = JOptionPane.showInputDialog("Enter New Password:");
                if(updatedPassword == null)
                	break;
                bms.updatePassword(updatedPassword);
                break;
            case "10": 
                String newAccountId = JOptionPane.showInputDialog("Enter New Account ID:");
                if(newAccountId == null)
                	break;
                bms.updateAccountId(newAccountId);
                break;
            case "11": 
                bms.displayAllAccounts();
                break;
            case "12": 
                bms.displayTransactionHistory();
                break;
            case "13": 
                bms.logout();
                break;
            case "14": 
                JOptionPane.showMessageDialog(null, "Exiting the Banking Management System. Thank you!");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
        }
    } while (!choice.equals("14"));
    	}
	}
